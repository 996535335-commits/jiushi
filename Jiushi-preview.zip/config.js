window.JIUSHI_BASE_PATH="/jiushi";
window.JIUSHI_SITE_ORIGIN="https://996535335-commits.github.io";
