window.JIUSHI_RELEASES=[
  {
    "id": "netease-406510616",
    "name": "下雨",
    "type": "single",
    "date": "2026-10-31",
    "tracks": [
      "下雨"
    ],
    "songIds": [
      3454732544
    ],
    "netease": "https://music.163.com/#/album?id=406510616",
    "image": "assets/music/406510616.jpg",
    "netId": 406510616,
    "apple": "https://music.apple.com/us/album/%E4%B8%8B%E9%9B%A8-single/6827805820?uo=4"
  },
  {
    "id": "netease-406511236",
    "name": "横街头粿子店",
    "type": "single",
    "date": "2026-10-31",
    "tracks": [
      "横街头粿子店"
    ],
    "songIds": [
      3454733226
    ],
    "netease": "https://music.163.com/#/album?id=406511236",
    "image": "assets/music/406511236.jpg",
    "netId": 406511236,
    "apple": "https://music.apple.com/us/album/%E6%A8%AA%E8%A1%97%E5%A4%B4%E7%B2%BF%E5%AD%90%E5%BA%97-single/6827806370?uo=4"
  },
  {
    "id": "netease-395229531",
    "name": "Day 1",
    "type": "single",
    "date": "2026-08-31",
    "tracks": [
      "Day 1"
    ],
    "songIds": [
      3427653463
    ],
    "netease": "https://music.163.com/#/album?id=395229531",
    "image": "assets/music/395229531.jpg",
    "netId": 395229531,
    "apple": "https://music.apple.com/us/album/day-1-single/6805408383?uo=4"
  },
  {
    "id": "netease-395229522",
    "name": "Who's rapping？",
    "type": "single",
    "date": "2026-08-31",
    "tracks": [
      "Who's rapping？"
    ],
    "songIds": [
      3427653433
    ],
    "netease": "https://music.163.com/#/album?id=395229522",
    "image": "assets/music/395229522.jpg",
    "netId": 395229522,
    "apple": "https://music.apple.com/us/album/whos-rapping-single/6805409237?uo=4"
  },
  {
    "id": "netease-383399441",
    "name": "按键伤人",
    "type": "single",
    "date": "2026-06-25",
    "tracks": [
      "按键伤人"
    ],
    "songIds": [
      3397456751
    ],
    "netease": "https://music.163.com/#/album?id=383399441",
    "image": "assets/music/383399441.jpg",
    "netId": 383399441,
    "apple": "https://music.apple.com/us/album/%E6%8C%89%E9%94%AE%E4%BC%A4%E4%BA%BA-single/6784171810?uo=4"
  },
  {
    "id": "netease-383396116",
    "name": "现在不见面下次也得见面那不如现在就见面",
    "type": "single",
    "date": "2026-06-25",
    "tracks": [
      "现在不见面下次也得见面那不如现在就见面"
    ],
    "songIds": [
      3397453411
    ],
    "netease": "https://music.163.com/#/album?id=383396116",
    "image": "assets/music/383396116.jpg",
    "netId": 383396116,
    "apple": "https://music.apple.com/us/album/%E7%8E%B0%E5%9C%A8%E4%B8%8D%E8%A7%81%E9%9D%A2%E4%B8%8B%E6%AC%A1%E4%B9%9F%E5%BE%97%E8%A7%81%E9%9D%A2%E9%82%A3%E4%B8%8D%E5%A6%82%E7%8E%B0%E5%9C%A8%E5%B0%B1%E8%A7%81%E9%9D%A2-single/6784175960?uo=4"
  },
  {
    "id": "netease-289127371",
    "name": "武夷调",
    "type": "single",
    "date": "2025-10-22",
    "tracks": [
      "武夷调"
    ],
    "songIds": [
      2757499926
    ],
    "netease": "https://music.163.com/#/album?id=289127371",
    "image": "assets/music/289127371.jpg",
    "netId": 289127371,
    "apple": "https://music.apple.com/us/album/%E6%AD%A6%E5%A4%B7%E8%B0%83-single/1860471701?uo=4"
  },
  {
    "id": "netease-250881620",
    "name": "Vulgar Human",
    "type": "ep",
    "date": "2024-10-18",
    "tracks": [
      "Hands up",
      "Check",
      "King Size",
      "黑怕福来",
      "V.H.C",
      "Vulgar Human"
    ],
    "songIds": [
      2637042306,
      2637042310,
      2637042308,
      2637042309,
      2637042307,
      2637042311
    ],
    "netease": "https://music.163.com/#/album?id=250881620",
    "image": "assets/music/250881620.jpg",
    "netId": 250881620,
    "apple": "https://music.apple.com/us/album/vulgar-human-ep/1860471762?uo=4"
  },
  {
    "id": "netease-250108353",
    "name": "31马赫",
    "type": "single",
    "date": "2024-10-10",
    "tracks": [
      "31马赫"
    ],
    "songIds": [
      2634588334
    ],
    "netease": "https://music.163.com/#/album?id=250108353",
    "image": "assets/music/250108353.jpg",
    "netId": 250108353,
    "apple": "https://music.apple.com/us/album/31%E9%A9%AC%E8%B5%AB-single/1860471620?uo=4"
  },
  {
    "id": "netease-248814647",
    "name": "一街好戏(现场版)",
    "type": "single",
    "date": "2024-09-25",
    "tracks": [
      "一街好戏(现场版)"
    ],
    "songIds": [
      2630290671
    ],
    "netease": "https://music.163.com/#/album?id=248814647",
    "image": "assets/music/248814647.jpg",
    "netId": 248814647
  },
  {
    "id": "netease-164271779",
    "name": "Knock！Knock！",
    "type": "single",
    "date": "2023-04-24",
    "tracks": [
      "Knock！Knock！"
    ],
    "songIds": [
      2042030360
    ],
    "netease": "https://music.163.com/#/album?id=164271779",
    "image": "assets/music/164271779.jpg",
    "netId": 164271779
  },
  {
    "id": "netease-125882410",
    "name": "ღ",
    "type": "single",
    "date": "2021-04-11",
    "tracks": [
      "ღ"
    ],
    "songIds": [
      2712620573
    ],
    "netease": "https://music.163.com/#/album?id=125882410",
    "image": "assets/music/125882410.jpg",
    "netId": 125882410
  },
  {
    "id": "netease-89847824",
    "name": "作何感想",
    "type": "single",
    "date": "2020-05-23",
    "tracks": [
      "作何感想"
    ],
    "songIds": [
      1450387304
    ],
    "netease": "https://music.163.com/#/album?id=89847824",
    "image": "assets/music/89847824.jpg",
    "netId": 89847824
  }
];
window.JIUSHI_TRACKS=[
  {
    "id": 3454732544,
    "name": "下雨",
    "album": "下雨",
    "artists": [
      "Vulgar Human",
      "高有钱"
    ],
    "duration": 198139,
    "netease": "https://music.163.com/#/song?id=3454732544",
    "apple": "https://music.apple.com/us/album/%E4%B8%8B%E9%9B%A8/6827805820?i=6827805823&uo=4"
  },
  {
    "id": 1450387304,
    "name": "作何感想",
    "album": "作何感想",
    "artists": [
      "Vulgar Human",
      "-v廉",
      "李星言"
    ],
    "duration": 250853,
    "netease": "https://music.163.com/#/song?id=1450387304"
  },
  {
    "id": 1855760959,
    "name": "K.O.",
    "album": "K.O.",
    "artists": [
      "HIPPO河马",
      "Vulgar Human"
    ],
    "duration": 138500,
    "netease": "https://music.163.com/#/song?id=1855760959"
  },
  {
    "id": 1475421341,
    "name": "燎原",
    "album": "燎原",
    "artists": [
      "HaLo",
      "Vulgar Human",
      "EighteeN CM(十八公分）Music",
      "杨柏青"
    ],
    "duration": 188000,
    "netease": "https://music.163.com/#/song?id=1475421341"
  },
  {
    "id": 1950451571,
    "name": "等等",
    "album": "等等",
    "artists": [
      "淙磬寺寺长",
      "小吴医生Chi Jay",
      "Vulgar Human"
    ],
    "duration": 222690,
    "netease": "https://music.163.com/#/song?id=1950451571"
  },
  {
    "id": 1938125853,
    "name": "憾",
    "album": "憾",
    "artists": [
      "PinKi",
      "Vulgar Human"
    ],
    "duration": 228000,
    "netease": "https://music.163.com/#/song?id=1938125853"
  },
  {
    "id": 1933509018,
    "name": "重症监护 2022 CYPHER Pt.2 ( 李庚运 Vicky 十万伏特 XXXLouiG )",
    "album": "ICU 2022 CYPHER",
    "artists": [
      "Vulgar Human",
      "十万伏特-J&T",
      "XXXLouiG",
      "ICU重症监护",
      "Vicky謝詩琪"
    ],
    "duration": 137320,
    "netease": "https://music.163.com/#/song?id=1933509018"
  },
  {
    "id": 2712620573,
    "name": "ღ",
    "album": "ღ",
    "artists": [
      "Vulgar Human"
    ],
    "duration": 221016,
    "netease": "https://music.163.com/#/song?id=2712620573"
  },
  {
    "id": 1965648221,
    "name": "0599Freestyle",
    "album": "0599Freestyle",
    "artists": [
      "HaLo",
      "Vulgar Human",
      "杨柏青"
    ],
    "duration": 196000,
    "netease": "https://music.163.com/#/song?id=1965648221"
  },
  {
    "id": 2042030360,
    "name": "Knock！Knock！",
    "album": "Knock！Knock！",
    "artists": [
      "Vulgar Human",
      "HaLo"
    ],
    "duration": 182726,
    "netease": "https://music.163.com/#/song?id=2042030360"
  },
  {
    "id": 2637042309,
    "name": "黑怕福来",
    "album": "Vulgar Human",
    "artists": [
      "Vulgar Human",
      "信義合"
    ],
    "duration": 182869,
    "netease": "https://music.163.com/#/song?id=2637042309",
    "apple": "https://music.apple.com/us/album/%E9%BB%91%E6%80%95%E7%A6%8F%E6%9D%A5/1860471762?i=1860471971&uo=4"
  },
  {
    "id": 2630290671,
    "name": "一街好戏(现场版)",
    "album": "一街好戏(现场版)",
    "artists": [
      "Vulgar Human",
      "信義合"
    ],
    "duration": 134145,
    "netease": "https://music.163.com/#/song?id=2630290671"
  },
  {
    "id": 2637042310,
    "name": "Check",
    "album": "Vulgar Human",
    "artists": [
      "Vulgar Human",
      "信義合"
    ],
    "duration": 206866,
    "netease": "https://music.163.com/#/song?id=2637042310",
    "apple": "https://music.apple.com/us/album/check/1860471762?i=1860471771&uo=4"
  },
  {
    "id": 2757499926,
    "name": "武夷调",
    "album": "武夷调",
    "artists": [
      "Vulgar Human",
      "信義合"
    ],
    "duration": 135700,
    "netease": "https://music.163.com/#/song?id=2757499926",
    "apple": "https://music.apple.com/us/album/%E6%AD%A6%E5%A4%B7%E8%B0%83/1860471701?i=1860471706&uo=4"
  },
  {
    "id": 2637042311,
    "name": "Vulgar Human",
    "album": "Vulgar Human",
    "artists": [
      "Vulgar Human",
      "信義合"
    ],
    "duration": 208666,
    "netease": "https://music.163.com/#/song?id=2637042311",
    "apple": "https://music.apple.com/us/album/vulgar-human/1860471762?i=1860471979&uo=4"
  },
  {
    "id": 3397453411,
    "name": "现在不见面下次也得见面那不如现在就见面",
    "album": "现在不见面下次也得见面那不如现在就见面",
    "artists": [
      "Vulgar Human"
    ],
    "duration": 185416,
    "netease": "https://music.163.com/#/song?id=3397453411",
    "apple": "https://music.apple.com/us/album/%E7%8E%B0%E5%9C%A8%E4%B8%8D%E8%A7%81%E9%9D%A2%E4%B8%8B%E6%AC%A1%E4%B9%9F%E5%BE%97%E8%A7%81%E9%9D%A2%E9%82%A3%E4%B8%8D%E5%A6%82%E7%8E%B0%E5%9C%A8%E5%B0%B1%E8%A7%81%E9%9D%A2/6784175960?i=6784175964&uo=4"
  },
  {
    "id": 3454733226,
    "name": "横街头粿子店",
    "album": "横街头粿子店",
    "artists": [
      "Vulgar Human"
    ],
    "duration": 180705,
    "netease": "https://music.163.com/#/song?id=3454733226",
    "apple": "https://music.apple.com/us/album/%E6%A8%AA%E8%A1%97%E5%A4%B4%E7%B2%BF%E5%AD%90%E5%BA%97/6827806370?i=6827806375&uo=4"
  },
  {
    "id": 3427653433,
    "name": "Who's rapping？",
    "album": "Who's rapping？",
    "artists": [
      "Vulgar Human"
    ],
    "duration": 155368,
    "netease": "https://music.163.com/#/song?id=3427653433",
    "apple": "https://music.apple.com/us/album/whos-rapping/6805409237?i=6805409239&uo=4"
  },
  {
    "id": 3427653463,
    "name": "Day 1",
    "album": "Day 1",
    "artists": [
      "Vulgar Human"
    ],
    "duration": 175027,
    "netease": "https://music.163.com/#/song?id=3427653463",
    "apple": "https://music.apple.com/us/album/day-1/6805408383?i=6805408387&uo=4"
  },
  {
    "id": 1460871915,
    "name": "Let’s Move",
    "album": "LET’S MOVE",
    "artists": [
      "HaLo",
      "Vulgar Human",
      "EighteeN CM(十八公分）Music",
      "杨柏青"
    ],
    "duration": 186000,
    "netease": "https://music.163.com/#/song?id=1460871915"
  },
  {
    "id": 2637042306,
    "name": "Hands up",
    "album": "Vulgar Human",
    "artists": [
      "Vulgar Human",
      "信義合"
    ],
    "duration": 152500,
    "netease": "https://music.163.com/#/song?id=2637042306",
    "apple": "https://music.apple.com/us/album/hands-up/1860471762?i=1860471767&uo=4"
  },
  {
    "id": 2637042307,
    "name": "V.H.C",
    "album": "Vulgar Human",
    "artists": [
      "Vulgar Human",
      "信義合"
    ],
    "duration": 176076,
    "netease": "https://music.163.com/#/song?id=2637042307",
    "apple": "https://music.apple.com/us/album/v-h-c/1860471762?i=1860471978&uo=4"
  },
  {
    "id": 2634588334,
    "name": "31马赫",
    "album": "31马赫",
    "artists": [
      "Vulgar Human"
    ],
    "duration": 222000,
    "netease": "https://music.163.com/#/song?id=2634588334",
    "apple": "https://music.apple.com/us/album/31%E9%A9%AC%E8%B5%AB/1860471620?i=1860471622&uo=4"
  },
  {
    "id": 2637042308,
    "name": "King Size",
    "album": "Vulgar Human",
    "artists": [
      "Vulgar Human",
      "信義合"
    ],
    "duration": 194954,
    "netease": "https://music.163.com/#/song?id=2637042308",
    "apple": "https://music.apple.com/us/album/king-size/1860471762?i=1860471966&uo=4"
  },
  {
    "id": 3397456751,
    "name": "按键伤人",
    "album": "按键伤人",
    "artists": [
      "Vulgar Human"
    ],
    "duration": 229550,
    "netease": "https://music.163.com/#/song?id=3397456751",
    "apple": "https://music.apple.com/us/album/%E6%8C%89%E9%94%AE%E4%BC%A4%E4%BA%BA/6784171810?i=6784171816&uo=4"
  }
];
window.JIUSHI_NETEASE_ARTIST="https://music.163.com/#/artist?id=13420180";
window.JIUSHI_APPLE_ARTIST="https://music.apple.com/us/artist/vulgar-human/1860454443?uo=4";
