window.JIUSHI_PARTNERS=[
  {
    "name": "The North Face 北面",
    "crop": [
      7,
      2160,
      155,
      86
    ],
    "image": "assets/vulgar-human-tour-original.jpg",
    "width": 1279,
    "url": "https://www.thenorthface.com.cn/",
    "light": true
  },
  {
    "name": "昂洋文化 ON YOUNG",
    "crop": [
      269,
      3294,
      107,
      47
    ],
    "image": "assets/chainsmokers-chengdu.jpg",
    "width": 2480,
    "url": null,
    "light": false
  },
  {
    "name": "国潮文化 CHINA COOL CULTURE",
    "crop": [
      769,
      3293,
      104,
      48
    ],
    "image": "assets/chainsmokers-chengdu.jpg",
    "width": 2480,
    "url": null,
    "light": false
  },
  {
    "name": "巡演联合主办文化单位",
    "crop": [
      1032,
      3288,
      53,
      58
    ],
    "image": "assets/chainsmokers-chengdu.jpg",
    "width": 2480,
    "url": null,
    "light": false
  },
  {
    "name": "SYMPHONY Group",
    "crop": [
      1106,
      3291,
      82,
      48
    ],
    "image": "assets/chainsmokers-chengdu.jpg",
    "width": 2480,
    "url": null,
    "light": false
  },
  {
    "name": "大名娱乐 BIG HONOR ENTERTAINMENT",
    "crop": [
      1113,
      3292,
      132,
      49
    ],
    "image": "assets/chainsmokers-foshan.jpg",
    "width": 2480,
    "url": null,
    "light": false
  },
  {
    "name": "灿然文化 CR CULTURE",
    "crop": [
      1208,
      3293,
      103,
      44
    ],
    "image": "assets/chainsmokers-chengdu.jpg",
    "width": 2480,
    "url": null,
    "light": false
  },
  {
    "name": "亿合文化 EASY HOT",
    "crop": [
      1417,
      3290,
      111,
      52
    ],
    "image": "assets/chainsmokers-chengdu.jpg",
    "width": 2480,
    "url": null,
    "light": false
  },
  {
    "name": "星辉传媒 STAR LIGHT MEDIA",
    "crop": [
      1463,
      3293,
      132,
      49
    ],
    "image": "assets/chainsmokers-foshan.jpg",
    "width": 2480,
    "url": null,
    "light": false
  },
  {
    "name": "大秦文化",
    "crop": [
      666,
      1655,
      76,
      30
    ],
    "image": "assets/chainsmokers-nanjing.jpg",
    "width": 1279,
    "url": null,
    "light": false
  },
  {
    "name": "欧森文化",
    "crop": [
      752,
      1655,
      82,
      30
    ],
    "image": "assets/chainsmokers-nanjing.jpg",
    "width": 1279,
    "url": null,
    "light": false
  },
  {
    "name": "中集文化",
    "crop": [
      1619,
      3290,
      48,
      55
    ],
    "image": "assets/chainsmokers-chengdu.jpg",
    "width": 2480,
    "url": null,
    "light": false
  },
  {
    "name": "喜玩乐文化 WeFunny Music",
    "crop": [
      1826,
      3290,
      147,
      53
    ],
    "image": "assets/chainsmokers-chengdu.jpg",
    "width": 2480,
    "url": null,
    "light": false
  },
  {
    "name": "StyleWicked",
    "crop": [
      2257,
      3289,
      77,
      59
    ],
    "image": "assets/chainsmokers-chengdu.jpg",
    "width": 2480,
    "url": null,
    "light": false
  },
  {
    "name": "小红书音乐",
    "crop": [
      892,
      3384,
      105,
      34
    ],
    "image": "assets/chainsmokers-chengdu.jpg",
    "width": 2480,
    "url": "https://www.xiaohongshu.com/",
    "light": false
  },
  {
    "name": "大麦",
    "crop": [
      1180,
      3379,
      111,
      41
    ],
    "image": "assets/chainsmokers-chengdu.jpg",
    "width": 2480,
    "url": "https://www.damai.cn/",
    "light": false
  },
  {
    "name": "猫眼",
    "crop": [
      1464,
      3378,
      93,
      43
    ],
    "image": "assets/chainsmokers-chengdu.jpg",
    "width": 2480,
    "url": "https://www.maoyan.com/",
    "light": false
  },
  {
    "name": "巡演票务合作单位",
    "crop": [
      1581,
      3368,
      58,
      61
    ],
    "image": "assets/chainsmokers-chengdu.jpg",
    "width": 2480,
    "url": null,
    "light": false
  },
  {
    "name": "携程旅行",
    "crop": [
      1657,
      3380,
      173,
      39
    ],
    "image": "assets/chainsmokers-chengdu.jpg",
    "width": 2480,
    "url": "https://www.ctrip.com/",
    "light": false
  }
];
Object.entries({"zh": {"partnersTitle": "合作单位", "sponsorNote": "The North Face 北面曾赞助 Vulgar Human 巡演。", "tourPartners": "2024 中国巡演 · 项目合作单位", "partnerScope": "根据巡演海报署名展示参与单位；各单位职责以具体项目为准。", "officialSite": "官方网站", "musicPlatformNote": "中文优先网易云；其他语言优先 Apple Music。平台曲库可能因地区而不同；尚未匹配的 Apple Music 作品将打开艺人主页。"}, "en": {"partnersTitle": "Project collaborators", "sponsorNote": "The North Face sponsored the Vulgar Human tour.", "tourPartners": "2024 China tour · Project collaborators", "partnerScope": "Participating organizations as credited on the tour posters. Roles vary by project.", "officialSite": "Official website", "musicPlatformNote": "Chinese prioritizes NetEase; other languages prioritize Apple Music. Catalog availability varies by region. Unmatched Apple Music releases open the artist page."}, "ko": {"partnersTitle": "프로젝트 협력사", "sponsorNote": "The North Face는 Vulgar Human 투어를 후원했습니다.", "tourPartners": "2024 중국 투어 · 프로젝트 협력사", "partnerScope": "투어 포스터에 표기된 참여사입니다. 역할은 프로젝트별로 다릅니다.", "officialSite": "공식 웹사이트", "musicPlatformNote": "중국어는 NetEase, 다른 언어는 Apple Music을 우선합니다. 지역별 제공 작품이 다르며, 미확인 작품은 아티스트 페이지로 연결됩니다."}, "ja": {"partnersTitle": "プロジェクト協力企業", "sponsorNote": "The North FaceはVulgar Humanのツアーを支援しました。", "tourPartners": "2024 中国ツアー · プロジェクト協力企業", "partnerScope": "ツアーポスター記載の参加企業です。役割は各プロジェクトにより異なります。", "officialSite": "公式サイト", "musicPlatformNote": "中国語はNetEase、その他の言語はApple Musicを優先します。配信状況は地域により異なり、未確認の作品はアーティストページを開きます。"}, "fr": {"partnersTitle": "Collaborations", "sponsorNote": "The North Face a sponsorisé la tournée de Vulgar Human.", "tourPartners": "Tournée en Chine 2024 · Collaborateurs", "partnerScope": "Organismes mentionnés sur les affiches de tournée. Les rôles varient selon le projet.", "officialSite": "Site officiel", "musicPlatformNote": "Le chinois privilégie NetEase ; les autres langues, Apple Music. Le catalogue varie selon la région. Sans correspondance, la page de l’artiste s’ouvre."}, "de": {"partnersTitle": "Projektpartner", "sponsorNote": "The North Face unterstützte die Tour von Vulgar Human als Sponsor.", "tourPartners": "China-Tour 2024 · Projektpartner", "partnerScope": "Beteiligte Unternehmen laut Tourplakaten. Ihre Aufgaben unterscheiden sich je nach Projekt.", "officialSite": "Offizielle Website", "musicPlatformNote": "Chinesisch bevorzugt NetEase, andere Sprachen Apple Music. Die Verfügbarkeit hängt von der Region ab. Ohne Zuordnung öffnet sich die Künstlerseite."}, "es": {"partnersTitle": "Colaboraciones", "sponsorNote": "The North Face patrocinó la gira de Vulgar Human.", "tourPartners": "Gira por China 2024 · Colaboradores", "partnerScope": "Entidades acreditadas en los carteles de la gira. Las funciones varían según el proyecto.", "officialSite": "Sitio oficial", "musicPlatformNote": "El chino prioriza NetEase; los demás idiomas, Apple Music. El catálogo varía según la región. Sin coincidencia, se abre la página del artista."}}).forEach(([lang,copy])=>Object.assign(window.JIUSHI_COPY[lang],copy));
